<?php

function base64url_encode(string $data): string {
  return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function base64url_decode(string $data): string {
  $remainder = strlen($data) % 4;
  if ($remainder) {
    $padlen = 4 - $remainder;
    $data .= str_repeat('=', $padlen);
  }
  return base64_decode(strtr($data, '-_', '+/'));
}

function jwt_encode(array $payload): string {
  $secret = getenv('JWT_SECRET') ?: 'dev-jwt-secret-change-me';

  $header = ['alg' => 'HS256', 'typ' => 'JWT'];
  $segments = [
    base64url_encode(json_encode($header)),
    base64url_encode(json_encode($payload)),
  ];

  $signingInput = implode('.', $segments);
  $signature = hash_hmac('sha256', $signingInput, $secret, true);
  $segments[] = base64url_encode($signature);

  return implode('.', $segments);
}

function jwt_decode(string $token): ?array {
  $secret = getenv('JWT_SECRET') ?: 'dev-jwt-secret-change-me';

  $parts = explode('.', $token);
  if (count($parts) !== 3) return null;

  [$h64, $p64, $s64] = $parts;
  $signingInput = $h64 . '.' . $p64;

  $expectedSig = hash_hmac('sha256', $signingInput, $secret, true);
  $expectedSigB64 = base64url_encode($expectedSig);
  if (!hash_equals($expectedSigB64, $s64)) return null;

  $payloadRaw = base64url_decode($p64);
  if ($payloadRaw === false) return null;

  $payload = json_decode($payloadRaw, true);
  if (!is_array($payload)) return null;

  if (isset($payload['exp']) && time() >= (int)$payload['exp']) {
    return null;
  }

  return $payload;
}

