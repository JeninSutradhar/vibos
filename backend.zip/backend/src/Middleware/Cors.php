<?php

function cors_handle(): void {
  $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
  $allowedOriginsCsv = getenv('CORS_ALLOWED_ORIGINS') ?: '';

  if ($allowedOriginsCsv === '') {
    header('Access-Control-Allow-Origin: *');
  } else {
    $allowed = array_map('trim', explode(',', $allowedOriginsCsv));
    if (in_array($origin, $allowed, true)) {
      header("Access-Control-Allow-Origin: $origin");
    } else {
      // If origin not allowed, don't set allow-origin.
      // The browser will block the request.
    }
  }

  header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
  header('Access-Control-Allow-Headers: Content-Type, Authorization');
  header('Access-Control-Max-Age: 86400');

  if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
    http_response_code(204);
    exit;
  }
}

