<?php

require_once __DIR__ . '/../Auth/Jwt.php';

function require_admin(): array {
  $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
  if ($auth === '' || !str_starts_with($auth, 'Bearer ')) {
    json_response(401, ['success' => false, 'error' => ['message' => 'Unauthorized']]);
    exit;
  }

  $token = substr($auth, 7);
  $payload = jwt_decode($token);
  if (!$payload) {
    json_response(401, ['success' => false, 'error' => ['message' => 'Invalid token']]);
    exit;
  }

  return $payload;
}

