INSERT INTO admin_users (email, password_hash, role)
VALUES ('admin@vibos.com', '$2y$10$LO6vcW2eP076BRu/A2KW4OyRVWdoSgz.5vxW5zD7NN7krdBQGOGeC', 'admin');

INSERT INTO services (slug, title, subtitle, audience, what_we_do, benefits, tools, published)
VALUES
  (
    'insurance-back-office-support',
    'Insurance Back Office Support',
    'Specialized P&C operations support for agencies, brokers, and MGAs.',
    'Insurance agencies, insurance brokers, MGAs, and insurance service providers.',
    'We provide prospect entry, AMS updates, quoting support, policy servicing, binding assistance, payment follow-ups, and documentation management to keep insurance workflows fast and accurate.',
    JSON_ARRAY(
      'Faster turnaround for policy and servicing operations',
      'Better record accuracy and workflow consistency',
      'More time for your in-house team to focus on growth and sales'
    ),
    JSON_ARRAY('Applied Epic', 'AMS360', 'HawkSoft', 'EZLynx', 'Vertafore', 'Carrier portals'),
    1
  ),
  (
    'business-process-outsourcing',
    'Business Process Outsourcing (BPO)',
    'Reliable operational support for admin-heavy business workflows.',
    'Entrepreneurs, startups, SMBs, ecommerce companies, and consultants.',
    'Our team handles virtual assistant support, website updates, calendar and inbox coordination, data entry, research, ecommerce tasks, and routine operations so your core team can stay focused.',
    JSON_ARRAY(
      'Lower operational overhead with flexible support',
      'Improved execution speed on repetitive business tasks',
      'Scalable model as workload grows'
    ),
    JSON_ARRAY('Google Workspace', 'Shopify', 'WooCommerce', 'WordPress', 'Slack', 'Zoom', 'Trello'),
    1
  ),
  (
    'mca-back-office-support',
    'MCA Back-Office Support',
    'Operational support designed for Merchant Cash Advance teams.',
    'MCA providers, alternative lending firms, and MCA brokerages.',
    'We support MCA workflows with lead operations, document processing, statement analysis, application review support, underwriting assistance, and client communication coordination.',
    JSON_ARRAY(
      'Faster processing across high-volume application pipelines',
      'More structured lead and sales support operations',
      'Improved consistency across underwriting support tasks'
    ),
    JSON_ARRAY('CRM platforms', 'Excel', 'Google Sheets', 'Credit report tools', 'Email and chat systems'),
    1
  ),
  (
    'accounting-and-bookkeeping',
    'Accounting and Bookkeeping Services',
    'Accurate financial back-office support for growing businesses.',
    'SMBs, startups, entrepreneurs, and accounting firms.',
    'We support transaction recording, AP/AR updates, reconciliation, invoicing, expense tracking, payroll support, and reporting workflows to keep financial records complete and current.',
    JSON_ARRAY(
      'Cleaner records and improved financial visibility',
      'Better process consistency for recurring financial tasks',
      'Reduced cost versus scaling in-house accounting support'
    ),
    JSON_ARRAY('QuickBooks', 'Xero', 'Zoho Books', 'Excel', 'Google Sheets'),
    1
  ),
  (
    'digital-marketing-services',
    'Digital Marketing Services',
    'Execution-focused digital marketing support for lead generation.',
    'Startups, SMBs, agencies, ecommerce brands, and service businesses.',
    'We support social media operations, content workflows, SEO execution, paid campaign support, email marketing coordination, and performance tracking to strengthen your pipeline.',
    JSON_ARRAY(
      'More consistent campaign execution and follow-through',
      'Increased visibility and lead generation support',
      'Flexible support without expanding internal marketing headcount'
    ),
    NULL,
    1
  ),
  (
    'employee-benefits-administration-support',
    'Employee Benefits Administration Support',
    'Back-office support for benefits enrollment and administration tasks.',
    'Insurance agencies, benefits brokers, HR consulting firms, and employers.',
    'We assist with benefits system updates, enrollment and renewal support, records maintenance, documentation processing, and coordination with carriers or brokers.',
    JSON_ARRAY(
      'Reduced administrative pressure on HR and benefits teams',
      'Improved consistency in enrollment and renewal workflows',
      'Better day-to-day management of benefits documentation'
    ),
    NULL,
    1
  );

INSERT INTO blog_posts (slug, title, excerpt, category, tag, content, image_url, published, published_at)
VALUES
  (
    'reduce-insurance-back-office-delays',
    'How Insurance Agencies Can Reduce Back-Office Delays Without Hiring In-House',
    'A practical process design for agencies that need faster quoting, servicing, and policy updates with limited internal bandwidth.',
    'Operations',
    'Insurance',
    NULL,
    'https://images.unsplash.com/photo-1551434678-e076c223a692?w=800&h=500&fit=crop',
    1,
    '2026-01-10 00:00:00'
  ),
  (
    'building-dedicated-offshore-support-teams',
    'A Practical Framework for Building Dedicated Offshore Support Teams',
    'How fast-growing companies can transition from ad-hoc outsourcing to a repeatable dedicated support model.',
    'Case Study',
    'BPO',
    NULL,
    'https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=800&h=500&fit=crop',
    1,
    '2026-01-18 00:00:00'
  );

INSERT INTO careers_openings (title, type, mode, description, published, sort_order)
VALUES
  (
    'Insurance Back-Office Specialist',
    'Full-time',
    'Remote',
    'We are looking for professionals with strong communication, process discipline, and ownership mindset.',
    1,
    10
  ),
  (
    'Virtual Assistant - Operations',
    'Full-time',
    'Remote',
    'We are looking for professionals with strong communication, process discipline, and ownership mindset.',
    1,
    20
  ),
  (
    'Bookkeeping Support Associate',
    'Full-time',
    'Remote',
    'We are looking for professionals with strong communication, process discipline, and ownership mindset.',
    1,
    30
  );

INSERT INTO team_profiles (title, description, sort_order)
VALUES
  (
    'Insurance Operations Specialists',
    'Focused professionals supporting quoting, policy servicing, AMS updates, documentation, and operational continuity.',
    10
  ),
  (
    'Virtual Operations Team',
    'Dedicated assistants and process support specialists helping clients streamline repetitive business workflows.',
    20
  ),
  (
    'Finance and MCA Support Team',
    'Execution-focused team supporting bookkeeping and MCA workflows with process consistency and clear communication.',
    30
  );

