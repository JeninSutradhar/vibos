<?php

declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../src/Util/Response.php';
require_once __DIR__ . '/../src/Middleware/Cors.php';
require_once __DIR__ . '/../src/Middleware/Auth.php';

cors_handle();

try {
  $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
  $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
  $body = ($method === 'POST' || $method === 'PUT' || $method === 'PATCH') ? json_input() : [];

  // Helper closures
  $success = function (array $data = []) use ($path): void {
    json_response(200, ['success' => true] + ($data ? ['data' => $data] : []));
  };

  $fail = function (int $status, string $message, array $details = []) use ($path): void {
    json_response($status, [
      'success' => false,
      'error' => ['message' => $message] + ($details ? ['details' => $details] : []),
    ]);
  };

  $not_found = function () use ($fail): void {
    $fail(404, 'Not found');
  };

  $isValidEmail = function (string $email): bool {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
  };

  // Public lead endpoints
  if ($method === 'POST' && $path === '/api/leads/contact') {
    $required = ['name', 'email', 'company', 'country', 'serviceInterest', 'message', 'sourcePage', 'utmSource', 'utmMedium', 'utmCampaign'];
    foreach ($required as $k) {
      if (!array_key_exists($k, $body)) {
        $fail(400, 'Missing field: ' . $k);
        exit;
      }
    }
    if (!$isValidEmail((string)$body['email'])) {
      $fail(400, 'Invalid email');
      exit;
    }
    if (isset($body['honeypot']) && (string)$body['honeypot'] !== '') {
      $success(); // treat as success to reduce spam tooling signal
      exit;
    }

    $leadType = 'contact';
    $status = 'new';
    $db = db();
    $stmt = $db->prepare('
      INSERT INTO leads
      (lead_type, name, email, company, country, service_interest, message, source_page, utm_source, utm_medium, utm_campaign, status)
      VALUES
      (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ');
    $stmt->bind_param(
      'ssssssssssss',
      $leadType,
      $body['name'],
      $body['email'],
      $body['company'],
      $body['country'],
      $body['serviceInterest'],
      $body['message'],
      $body['sourcePage'],
      $body['utmSource'],
      $body['utmMedium'],
      $body['utmCampaign'],
      $status
    );
    $stmt->execute();

    json_response(200, ['success' => true]);
    exit;
  }

  if ($method === 'POST' && $path === '/api/leads/quote') {
    $required = ['name', 'email', 'company', 'country', 'serviceInterest', 'message', 'sourcePage', 'utmSource', 'utmMedium', 'utmCampaign'];
    foreach ($required as $k) {
      if (!array_key_exists($k, $body)) {
        $fail(400, 'Missing field: ' . $k);
        exit;
      }
    }
    if (!$isValidEmail((string)$body['email'])) {
      $fail(400, 'Invalid email');
      exit;
    }
    if (isset($body['honeypot']) && (string)$body['honeypot'] !== '') {
      $success();
      exit;
    }

    $db = db();
    $stmt = $db->prepare('
      INSERT INTO leads
      (lead_type, name, email, company, country, service_interest, message, monthly_volume, team_size_needed, preferred_start_date, source_page, utm_source, utm_medium, utm_campaign, status)
      VALUES
      (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ');
    $leadType = 'quote';
    $status = 'new';
    $stmt->bind_param(
      'sssssssssssssss',
      $leadType,
      $body['name'],
      $body['email'],
      $body['company'],
      $body['country'],
      $body['serviceInterest'],
      $body['message'],
      $body['monthlyVolume'],
      $body['teamSizeNeeded'],
      $body['preferredStartDate'],
      $body['sourcePage'],
      $body['utmSource'],
      $body['utmMedium'],
      $body['utmCampaign'],
      $status
    );
    $stmt->execute();

    json_response(200, ['success' => true]);
    exit;
  }

  if ($method === 'POST' && $path === '/api/leads/callback') {
    $required = ['name', 'email', 'company', 'country', 'serviceInterest', 'preferredTime', 'sourcePage', 'utmSource', 'utmMedium', 'utmCampaign'];
    foreach ($required as $k) {
      if (!array_key_exists($k, $body)) {
        $fail(400, 'Missing field: ' . $k);
        exit;
      }
    }
    if (!$isValidEmail((string)$body['email'])) {
      $fail(400, 'Invalid email');
      exit;
    }
    if (isset($body['honeypot']) && (string)$body['honeypot'] !== '') {
      $success();
      exit;
    }

    $db = db();
    $stmt = $db->prepare('
      INSERT INTO leads
      (lead_type, name, email, company, country, service_interest, message, preferred_time, source_page, utm_source, utm_medium, utm_campaign, status)
      VALUES
      (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ');
    $leadType = 'callback';
    $status = 'new';
    $message = array_key_exists('message', $body) ? $body['message'] : null;
    $stmt->bind_param(
      'sssssssssssss',
      $leadType,
      $body['name'],
      $body['email'],
      $body['company'],
      $body['country'],
      $body['serviceInterest'],
      $message,
      $body['preferredTime'],
      $body['sourcePage'],
      $body['utmSource'],
      $body['utmMedium'],
      $body['utmCampaign'],
      $status
    );
    $stmt->execute();
    json_response(200, ['success' => true]);
    exit;
  }

  if ($method === 'POST' && $path === '/api/newsletter/subscribe') {
    $email = (string)($body['email'] ?? '');
    if ($email === '' || !$isValidEmail($email)) {
      $fail(400, 'Valid email is required');
      exit;
    }
    $db = db();
    $stmt = $db->prepare('INSERT INTO newsletter_subscribers (email, status) VALUES (?, ?) ON DUPLICATE KEY UPDATE status=VALUES(status)');
    $status = 'subscribed';
    $stmt->bind_param('ss', $email, $status);
    $stmt->execute();
    json_response(200, ['success' => true]);
    exit;
  }

  if ($method === 'POST' && $path === '/api/analytics/events') {
    $eventName = (string)($body['eventName'] ?? '');
    $page = (string)($body['page'] ?? '');
    if ($eventName === '' || $page === '') {
      $fail(400, 'eventName and page are required');
      exit;
    }
    $metadata = $body['metadata'] ?? null;
    $db = db();
    $stmt = $db->prepare('INSERT INTO analytics_events (event_name, page, metadata) VALUES (?, ?, ?)');
    $metadataJson = $metadata === null ? '{}' : json_encode($metadata);
    $stmt->bind_param('sss', $eventName, $page, $metadataJson);
    $stmt->execute();
    json_response(200, ['success' => true]);
    exit;
  }

  // Content read endpoints
  if ($method === 'GET' && $path === '/api/services') {
    $db = db();
    $rows = $db->query('SELECT slug, title, subtitle, audience, what_we_do, benefits, tools, published FROM services WHERE published=1 ORDER BY title ASC');
    $services = [];
    while ($r = $rows->fetch_assoc()) {
      $services[] = [
        'slug' => $r['slug'],
        'title' => $r['title'],
        'subtitle' => $r['subtitle'],
        'audience' => $r['audience'],
        'whatWeDo' => $r['what_we_do'],
        'benefits' => $r['benefits'] ? json_decode($r['benefits'], true) : [],
        'tools' => $r['tools'] ? json_decode($r['tools'], true) : null,
      ];
    }
    json_response(200, ['success' => true, 'data' => $services]);
    exit;
  }

  if ($method === 'GET' && preg_match('#^/api/services/([^/]+)$#', $path, $m)) {
    $slug = $m[1];
    $db = db();
    $stmt = $db->prepare('SELECT slug, title, subtitle, audience, what_we_do, benefits, tools, published FROM services WHERE slug=? AND published=1');
    $stmt->bind_param('s', $slug);
    $stmt->execute();
    $res = $stmt->get_result();
    $r = $res->fetch_assoc();
    if (!$r) {
      $fail(404, 'Service not found');
      exit;
    }
    json_response(200, [
      'success' => true,
      'data' => [
        'slug' => $r['slug'],
        'title' => $r['title'],
        'subtitle' => $r['subtitle'],
        'audience' => $r['audience'],
        'whatWeDo' => $r['what_we_do'],
        'benefits' => $r['benefits'] ? json_decode($r['benefits'], true) : [],
        'tools' => $r['tools'] ? json_decode($r['tools'], true) : null,
      ],
    ]);
    exit;
  }

  if ($method === 'GET' && $path === '/api/blog') {
    $db = db();
    $rows = $db->query('SELECT slug, title, excerpt, category, tag, image_url, published_at, published FROM blog_posts WHERE published=1 ORDER BY published_at DESC');
    $posts = [];
    while ($r = $rows->fetch_assoc()) {
      $posts[] = [
        'slug' => $r['slug'],
        'title' => $r['title'],
        'excerpt' => $r['excerpt'],
        'category' => $r['category'],
        'tag' => $r['tag'],
        'image' => $r['image_url'],
        'date' => $r['published_at'] ? date('F d, Y', strtotime($r['published_at'])) : '',
      ];
    }
    json_response(200, ['success' => true, 'data' => $posts]);
    exit;
  }

  if ($method === 'GET' && preg_match('#^/api/blog/([^/]+)$#', $path, $m)) {
    $slug = $m[1];
    $db = db();
    $stmt = $db->prepare('SELECT slug, title, excerpt, category, tag, image_url, published_at, content FROM blog_posts WHERE slug=? AND published=1');
    $stmt->bind_param('s', $slug);
    $stmt->execute();
    $res = $stmt->get_result();
    $r = $res->fetch_assoc();
    if (!$r) {
      $fail(404, 'Blog post not found');
      exit;
    }
    json_response(200, [
      'success' => true,
      'data' => [
        'slug' => $r['slug'],
        'title' => $r['title'],
        'excerpt' => $r['excerpt'],
        'category' => $r['category'],
        'tag' => $r['tag'],
        'image' => $r['image_url'],
        'date' => $r['published_at'] ? date('F d, Y', strtotime($r['published_at'])) : '',
        'content' => $r['content'] ? json_decode($r['content'], true) : null,
      ],
    ]);
    exit;
  }

  if ($method === 'GET' && $path === '/api/careers') {
    $db = db();
    $rows = $db->query('SELECT id, title, type, mode, description, published FROM careers_openings WHERE published=1 ORDER BY sort_order ASC');
    $openings = [];
    while ($r = $rows->fetch_assoc()) {
      $openings[] = [
        'id' => (int)$r['id'],
        'title' => $r['title'],
        'type' => $r['type'],
        'mode' => $r['mode'],
        'description' => $r['description'],
      ];
    }
    json_response(200, ['success' => true, 'data' => $openings]);
    exit;
  }

  if ($method === 'GET' && $path === '/api/team') {
    $db = db();
    $rows = $db->query('SELECT id, title, description, sort_order FROM team_profiles ORDER BY sort_order ASC');
    $profiles = [];
    while ($r = $rows->fetch_assoc()) {
      $profiles[] = [
        'id' => (int)$r['id'],
        'title' => $r['title'],
        'description' => $r['description'],
      ];
    }
    json_response(200, ['success' => true, 'data' => $profiles]);
    exit;
  }

  // Admin authentication
  if ($method === 'POST' && $path === '/api/admin/auth/login') {
    $email = (string)($body['email'] ?? '');
    $password = (string)($body['password'] ?? '');
    if ($email === '' || $password === '') {
      $fail(400, 'Email and password are required');
      exit;
    }
    if (!$isValidEmail($email)) {
      $fail(400, 'Invalid email');
      exit;
    }

    $db = db();
    $stmt = $db->prepare('SELECT id, email, password_hash, role FROM admin_users WHERE email=? LIMIT 1');
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $res = $stmt->get_result();
    $u = $res->fetch_assoc();
    if (!$u || !password_verify($password, $u['password_hash'])) {
      $fail(401, 'Invalid credentials');
      exit;
    }

    $payload = [
      'sub' => (int)$u['id'],
      'role' => $u['role'],
      'exp' => time() + 3600,
    ];
    $token = jwt_encode($payload);
    json_response(200, ['success' => true, 'data' => ['token' => $token]]);
    exit;
  }

  // Admin leads listing + status update
  if ($path === '/api/admin/leads' && $method === 'GET') {
    $payload = require_admin();
    $db = db();

    $leadType = (string)($_GET['lead_type'] ?? '');
    $status = (string)($_GET['status'] ?? '');
    $q = (string)($_GET['q'] ?? '');
    $from = (string)($_GET['from'] ?? '');
    $to = (string)($_GET['to'] ?? '');

    $where = ['1=1'];
    $types = [];
    $values = [];

    if ($leadType !== '') { $where[] = 'lead_type=?'; $types[]='s'; $values[]=$leadType; }
    if ($status !== '') { $where[] = 'status=?'; $types[]='s'; $values[]=$status; }
    if ($q !== '') {
      $where[] = '(name LIKE ? OR email LIKE ? OR company LIKE ? OR service_interest LIKE ?)';
      $types = array_merge($types, ['s','s','s','s']);
      $v = '%' . $q . '%';
      $values = array_merge($values, [$v,$v,$v,$v]);
    }
    if ($from !== '') { $where[] = 'created_at >= ?'; $types[]='s'; $values[]=$from; }
    if ($to !== '') { $where[] = 'created_at <= ?'; $types[]='s'; $values[]=$to; }

    $sql = 'SELECT id, lead_type, name, email, company, country, service_interest, message, preferred_time, monthly_volume, team_size_needed, preferred_start_date, source_page, utm_source, utm_medium, utm_campaign, status, internal_notes, created_at
            FROM leads
            WHERE ' . implode(' AND ', $where) . '
            ORDER BY created_at DESC
            LIMIT 500';

    $stmt = $db->prepare($sql);
    if (count($values) > 0) {
      $stmt->bind_param(str_repeat('s', count($values)), ...$values);
    }
    $stmt->execute();
    $res = $stmt->get_result();
    $items = [];
    while ($r = $res->fetch_assoc()) {
      $items[] = [
        'id' => (int)$r['id'],
        'leadType' => $r['lead_type'],
        'name' => $r['name'],
        'email' => $r['email'],
        'company' => $r['company'],
        'country' => $r['country'],
        'serviceInterest' => $r['service_interest'],
        'message' => $r['message'],
        'preferredTime' => $r['preferred_time'],
        'monthlyVolume' => $r['monthly_volume'],
        'teamSizeNeeded' => $r['team_size_needed'],
        'preferredStartDate' => $r['preferred_start_date'],
        'sourcePage' => $r['source_page'],
        'utmSource' => $r['utm_source'],
        'utmMedium' => $r['utm_medium'],
        'utmCampaign' => $r['utm_campaign'],
        'status' => $r['status'],
        'internalNotes' => $r['internal_notes'],
        'createdAt' => $r['created_at'],
      ];
    }
    json_response(200, ['success' => true, 'data' => ['items' => $items]]);
    exit;
  }

  if ($method === 'GET' && preg_match('#^/api/admin/leads/(\\d+)$#', $path, $m)) {
    $payload = require_admin();
    $id = (int)$m[1];
    $db = db();
    $stmt = $db->prepare('SELECT id, lead_type, name, email, company, country, service_interest, message, preferred_time, monthly_volume, team_size_needed, preferred_start_date, source_page, utm_source, utm_medium, utm_campaign, status, internal_notes, created_at FROM leads WHERE id=? LIMIT 1');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $res = $stmt->get_result();
    $r = $res->fetch_assoc();
    if (!$r) {
      $fail(404, 'Lead not found');
      exit;
    }
    json_response(200, [
      'success' => true,
      'data' => [
        'id' => (int)$r['id'],
        'leadType' => $r['lead_type'],
        'name' => $r['name'],
        'email' => $r['email'],
        'company' => $r['company'],
        'country' => $r['country'],
        'serviceInterest' => $r['service_interest'],
        'message' => $r['message'],
        'preferredTime' => $r['preferred_time'],
        'monthlyVolume' => $r['monthly_volume'],
        'teamSizeNeeded' => $r['team_size_needed'],
        'preferredStartDate' => $r['preferred_start_date'],
        'sourcePage' => $r['source_page'],
        'utmSource' => $r['utm_source'],
        'utmMedium' => $r['utm_medium'],
        'utmCampaign' => $r['utm_campaign'],
        'status' => $r['status'],
        'internalNotes' => $r['internal_notes'],
        'createdAt' => $r['created_at'],
      ],
    ]);
    exit;
  }

  if ($method === 'PATCH' && preg_match('#^/api/admin/leads/(\\d+)$#', $path, $m)) {
    $payload = require_admin();
    $id = (int)$m[1];
    $status = (string)($body['status'] ?? '');
    $hasNotesKey = array_key_exists('internalNotes', $body);
    $notes = $hasNotesKey ? (string)$body['internalNotes'] : null;
    $db = db();

    if ($status === '' && $hasNotesKey) {
      $stmt = $db->prepare('UPDATE leads SET internal_notes=? WHERE id=?');
      $stmt->bind_param('si', $notes, $id);
    } elseif ($status !== '' && $hasNotesKey) {
      $stmt = $db->prepare('UPDATE leads SET status=?, internal_notes=? WHERE id=?');
      $stmt->bind_param('ssi', $status, $notes, $id);
    } elseif ($status !== '') {
      $stmt = $db->prepare('UPDATE leads SET status=? WHERE id=?');
      $stmt->bind_param('si', $status, $id);
    } else {
      $fail(400, 'Nothing to update');
      exit;
    }
    $stmt->execute();
    json_response(200, ['success' => true]);
    exit;
  }

  // Admin newsletter list
  if ($method === 'GET' && $path === '/api/admin/newsletter') {
    $payload = require_admin();
    $db = db();
    $rows = $db->query('SELECT id, email, status, created_at FROM newsletter_subscribers ORDER BY created_at DESC LIMIT 500');
    $items = [];
    while ($r = $rows->fetch_assoc()) {
      $items[] = [
        'id' => (int)$r['id'],
        'email' => $r['email'],
        'status' => $r['status'],
        'createdAt' => $r['created_at'],
      ];
    }
    json_response(200, ['success' => true, 'data' => ['items' => $items]]);
    exit;
  }

  // Admin services list
  if ($method === 'GET' && $path === '/api/admin/services') {
    $payload = require_admin();
    $db = db();
    $rows = $db->query('SELECT slug, title, subtitle, audience, what_we_do, benefits, tools, published FROM services ORDER BY title ASC');
    $items = [];
    while ($r = $rows->fetch_assoc()) {
      $items[] = [
        'slug' => $r['slug'],
        'title' => $r['title'],
        'subtitle' => $r['subtitle'],
        'audience' => $r['audience'],
        'whatWeDo' => $r['what_we_do'],
        'benefits' => $r['benefits'] ? json_decode($r['benefits'], true) : [],
        'tools' => $r['tools'] ? json_decode($r['tools'], true) : null,
        'published' => (int)$r['published'],
      ];
    }
    json_response(200, ['success' => true, 'data' => ['items' => $items]]);
    exit;
  }

  if ($method === 'GET' && preg_match('#^/api/admin/services/([^/]+)$#', $path, $m)) {
    $payload = require_admin();
    $slug = $m[1];
    $db = db();
    $stmt = $db->prepare('SELECT slug, title, subtitle, audience, what_we_do, benefits, tools, published FROM services WHERE slug=? LIMIT 1');
    $stmt->bind_param('s', $slug);
    $stmt->execute();
    $res = $stmt->get_result();
    $r = $res->fetch_assoc();
    if (!$r) {
      $fail(404, 'Service not found');
      exit;
    }
    json_response(200, [
      'success' => true,
      'data' => [
        'slug' => $r['slug'],
        'title' => $r['title'],
        'subtitle' => $r['subtitle'],
        'audience' => $r['audience'],
        'whatWeDo' => $r['what_we_do'],
        'benefits' => $r['benefits'] ? json_decode($r['benefits'], true) : [],
        'tools' => $r['tools'] ? json_decode($r['tools'], true) : null,
        'published' => (int)$r['published'],
      ],
    ]);
    exit;
  }

  // Admin blog list
  if ($method === 'GET' && $path === '/api/admin/blog-posts') {
    $payload = require_admin();
    $db = db();
    $rows = $db->query('SELECT slug, title, excerpt, category, tag, image_url, published, published_at FROM blog_posts ORDER BY published_at DESC');
    $items = [];
    while ($r = $rows->fetch_assoc()) {
      $items[] = [
        'slug' => $r['slug'],
        'title' => $r['title'],
        'excerpt' => $r['excerpt'],
        'category' => $r['category'],
        'tag' => $r['tag'],
        'image' => $r['image_url'],
        'published' => (int)$r['published'],
        'publishedAt' => $r['published_at'],
      ];
    }
    json_response(200, ['success' => true, 'data' => ['items' => $items]]);
    exit;
  }

  if ($method === 'GET' && preg_match('#^/api/admin/blog-posts/([^/]+)$#', $path, $m)) {
    $payload = require_admin();
    $slug = $m[1];
    $db = db();
    $stmt = $db->prepare('SELECT slug, title, excerpt, category, tag, image_url, content, published, published_at FROM blog_posts WHERE slug=? LIMIT 1');
    $stmt->bind_param('s', $slug);
    $stmt->execute();
    $res = $stmt->get_result();
    $r = $res->fetch_assoc();
    if (!$r) {
      $fail(404, 'Blog post not found');
      exit;
    }
    json_response(200, [
      'success' => true,
      'data' => [
        'slug' => $r['slug'],
        'title' => $r['title'],
        'excerpt' => $r['excerpt'],
        'category' => $r['category'],
        'tag' => $r['tag'],
        'image' => $r['image_url'],
        'content' => $r['content'] ? json_decode($r['content'], true) : null,
        'published' => (int)$r['published'],
        'publishedAt' => $r['published_at'],
      ],
    ]);
    exit;
  }

  // Admin careers list
  if ($method === 'GET' && $path === '/api/admin/careers-openings') {
    $payload = require_admin();
    $db = db();
    $rows = $db->query('SELECT id, title, type, mode, description, published, sort_order FROM careers_openings ORDER BY sort_order ASC');
    $items = [];
    while ($r = $rows->fetch_assoc()) {
      $items[] = [
        'id' => (int)$r['id'],
        'title' => $r['title'],
        'type' => $r['type'],
        'mode' => $r['mode'],
        'description' => $r['description'],
        'published' => (int)$r['published'],
        'sortOrder' => (int)$r['sort_order'],
      ];
    }
    json_response(200, ['success' => true, 'data' => ['items' => $items]]);
    exit;
  }

  // Admin team list
  if ($method === 'GET' && $path === '/api/admin/team-profiles') {
    $payload = require_admin();
    $db = db();
    $rows = $db->query('SELECT id, title, description, sort_order FROM team_profiles ORDER BY sort_order ASC');
    $items = [];
    while ($r = $rows->fetch_assoc()) {
      $items[] = [
        'id' => (int)$r['id'],
        'title' => $r['title'],
        'description' => $r['description'],
        'sortOrder' => (int)$r['sort_order'],
      ];
    }
    json_response(200, ['success' => true, 'data' => ['items' => $items]]);
    exit;
  }

  // Admin services upsert
  if ($method === 'PUT' && preg_match('#^/api/admin/services/([^/]+)$#', $path, $m)) {
    $payload = require_admin();
    $slug = $m[1];
    $db = db();

    $title = (string)($body['title'] ?? '');
    $subtitle = (string)($body['subtitle'] ?? '');
    $audience = (string)($body['audience'] ?? '');
    $whatWeDo = (string)($body['whatWeDo'] ?? '');
    $benefits = $body['benefits'] ?? [];
    $tools = array_key_exists('tools', $body) ? $body['tools'] : null;
    $published = (int)($body['published'] ?? 1);

    if ($title === '' || $subtitle === '' || $audience === '' || $whatWeDo === '' || !is_array($benefits)) {
      $fail(400, 'Invalid service payload');
      exit;
    }

    $benefitsJson = json_encode($benefits);
    $toolsJson = $tools === null ? null : json_encode($tools);

    $stmt = $db->prepare('
      INSERT INTO services (slug, title, subtitle, audience, what_we_do, benefits, tools, published)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE
        title=VALUES(title),
        subtitle=VALUES(subtitle),
        audience=VALUES(audience),
        what_we_do=VALUES(what_we_do),
        benefits=VALUES(benefits),
        tools=VALUES(tools),
        published=VALUES(published)
    ');
    $stmt->bind_param('sssssssi', $slug, $title, $subtitle, $audience, $whatWeDo, $benefitsJson, $toolsJson, $published);
    $stmt->execute();
    json_response(200, ['success' => true]);
    exit;
  }

  // Admin blog upsert
  if ($method === 'PUT' && preg_match('#^/api/admin/blog-posts/([^/]+)$#', $path, $m)) {
    $payload = require_admin();
    $slug = $m[1];
    $db = db();

    $title = (string)($body['title'] ?? '');
    $excerpt = (string)($body['excerpt'] ?? '');
    $category = (string)($body['category'] ?? '');
    $tag = (string)($body['tag'] ?? '');
    $imageUrl = (string)($body['image'] ?? ($body['imageUrl'] ?? ''));
    $content = $body['content'] ?? null;
    $published = (int)($body['published'] ?? 1);
    $publishedAt = (string)($body['publishedAt'] ?? '');

    if ($title === '' || $excerpt === '' || $category === '' || $tag === '') {
      $fail(400, 'Invalid blog post payload');
      exit;
    }

    $contentJson = $content === null ? null : json_encode($content);
    $publishedAtValue = $publishedAt !== '' ? $publishedAt : null;

    $stmt = $db->prepare('
      INSERT INTO blog_posts (slug, title, excerpt, category, tag, content, image_url, published, published_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE
        title=VALUES(title),
        excerpt=VALUES(excerpt),
        category=VALUES(category),
        tag=VALUES(tag),
        content=VALUES(content),
        image_url=VALUES(image_url),
        published=VALUES(published),
        published_at=VALUES(published_at)
    ');
    $stmt->bind_param('sssssssss', $slug, $title, $excerpt, $category, $tag, $contentJson, $imageUrl, $published, $publishedAtValue);
    $stmt->execute();
    json_response(200, ['success' => true]);
    exit;
  }

  // Admin careers upsert
  if ($method === 'PUT' && preg_match('#^/api/admin/careers-openings/(\\d+)$#', $path, $m)) {
    $payload = require_admin();
    $id = (int)$m[1];
    $db = db();

    $title = (string)($body['title'] ?? '');
    $type = (string)($body['type'] ?? '');
    $mode = (string)($body['mode'] ?? '');
    $description = (string)($body['description'] ?? '');
    $published = (int)($body['published'] ?? 1);

    if ($title === '' || $type === '' || $mode === '' || $description === '') {
      $fail(400, 'Invalid careers opening payload');
      exit;
    }

    $stmt = $db->prepare('UPDATE careers_openings SET title=?, type=?, mode=?, description=?, published=? WHERE id=?');
    $stmt->bind_param('ssssii', $title, $type, $mode, $description, $published, $id);
    $stmt->execute();
    json_response(200, ['success' => true]);
    exit;
  }

  // Admin team upsert
  if ($method === 'PUT' && preg_match('#^/api/admin/team-profiles/(\\d+)$#', $path, $m)) {
    $payload = require_admin();
    $id = (int)$m[1];
    $db = db();

    $title = (string)($body['title'] ?? '');
    $description = (string)($body['description'] ?? '');
    $sortOrder = (int)($body['sortOrder'] ?? 0);

    if ($title === '' || $description === '') {
      $fail(400, 'Invalid team profile payload');
      exit;
    }

    $stmt = $db->prepare('UPDATE team_profiles SET title=?, description=?, sort_order=? WHERE id=?');
    $stmt->bind_param('ssii', $title, $description, $sortOrder, $id);
    $stmt->execute();
    json_response(200, ['success' => true]);
    exit;
  }

  $not_found();
} catch (Throwable $e) {
  json_response(500, [
    'success' => false,
    'error' => [
      'message' => 'Server error',
      'details' => $e->getMessage(),
    ],
  ]);
}

