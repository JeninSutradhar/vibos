<?php

require_once __DIR__ . '/../src/Util/Env.php';

loadEnv(__DIR__ . '/.env');

function db(): mysqli {
  $host = getenv('DB_HOST') ?: '127.0.0.1';
  $port = getenv('DB_PORT') ?: '3306';
  $name = getenv('DB_NAME') ?: 'vibos_backend';
  $user = getenv('DB_USER') ?: 'root';
  // Dev fallback to match the provided MySQL root password.
  $pass = getenv('DB_PASS') ?: '12345678';

  static $conn = null;
  if ($conn instanceof mysqli) return $conn;

  mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

  $conn = new mysqli($host, $user, $pass, $name, (int)$port);
  $conn->set_charset('utf8mb4');
  return $conn;
}

